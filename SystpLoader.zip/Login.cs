using Loader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KeyAuth
{
    public partial class Login : Form
    {
        /*
        * 
        * this work By. *KING*#2036
        * 
        */

        static string name = ""; // application name. right above the blurred text aka the secret on the licenses tab among other tabs
        static string ownerid = ""; // ownerid, found in account settings. click your profile picture on top right of dashboard and then account settings.
        static string secret = ""; // app secret, the blurred text on licenses tab and other tabs
        static string version = "1.0"; // leave alone unless you've changed version on website

        public static api KeyAuthApp = new api(name, ownerid, secret, version);

        public Login()
        {
            InitializeComponent();
        }

        private void siticoneControlBox1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //if you want to ask about something, write to me DISCORD : *KING*#2036
            var web = new WebClient();
            up.Text = web.DownloadString("https://dl.dropbox.com/s/9admlq964u5ube4/test.txt?dl=0"); //Here it will check if there is a new version or not
            if (up.Text == "v1.0")
            {
                KeyAuthApp.init();
                if (KeyAuthApp.checkblack()) // check if hwid is blacklisted
                {
                    Environment.Exit(0);
                }
            }
            else
            {
                //If there is a release, you will be taken to the update page
                update frm = new update();
                frm.Show(this);
                this.Hide(); 

            }
        }

        private void LicBtn_Click(object sender, EventArgs e)
        {
            KeyAuthApp.license(key.Text);
            Main main = new Main();
            main.Show();
            this.Hide();
        }

        Random randomGen = new Random();
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
    }
}
