﻿
namespace Loader
{
    partial class update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(update));
            this.LicBtn = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.updatepar = new Siticone.UI.WinForms.SiticoneVProgressBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // LicBtn
            // 
            this.LicBtn.BackColor = System.Drawing.Color.Transparent;
            this.LicBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LicBtn.Location = new System.Drawing.Point(280, 190);
            this.LicBtn.Name = "LicBtn";
            this.LicBtn.Size = new System.Drawing.Size(202, 34);
            this.LicBtn.TabIndex = 35;
            this.LicBtn.Click += new System.EventHandler(this.LicBtn_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Location = new System.Drawing.Point(493, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 34);
            this.label1.TabIndex = 36;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // updatepar
            // 
            this.updatepar.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.updatepar.Location = new System.Drawing.Point(563, 0);
            this.updatepar.Name = "updatepar";
            this.updatepar.ProgressColor = System.Drawing.Color.Teal;
            this.updatepar.ProgressColor2 = System.Drawing.Color.Aquamarine;
            this.updatepar.ShadowDecoration.Parent = this.updatepar;
            this.updatepar.Size = new System.Drawing.Size(12, 268);
            this.updatepar.TabIndex = 37;
            this.updatepar.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Aquamarine;
            this.panel1.Location = new System.Drawing.Point(-1, -5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(579, 10);
            this.panel1.TabIndex = 38;
            // 
            // update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(575, 268);
            this.Controls.Add(this.updatepar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LicBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "update";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SystpLoaderw";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.update_FormClosing);
            this.Load += new System.EventHandler(this.update_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LicBtn;
        private System.Windows.Forms.Label label1;
        private Siticone.UI.WinForms.SiticoneVProgressBar updatepar;
        private System.Windows.Forms.Panel panel1;
    }
}