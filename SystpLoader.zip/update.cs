﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loader
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void update_Load(object sender, EventArgs e)
        {
            //updatepar.Visible = false;
        }

        private void LicBtn_Click(object sender, EventArgs e)
        {
            //Just change the version number in the text file in Dropbox and upload the new version without changing its name.
            //Change from www to dl in your link app 
            updatepar.Visible = true;
            WebClient client = new WebClient();
            //WebClient client2 = new WebClient();
            client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(Client_DownloadProgressChanged);
            client.DownloadFileCompleted += new AsyncCompletedEventHandler(Client_DownloadFileCompleted);
            client.DownloadFileAsync(new Uri("https://your-link-app"), "NeamApp.exe"); 
        }

        private void Client_DownloadProgressChanged(object sender, System.Net.DownloadProgressChangedEventArgs e)
        {
            updatepar.Maximum = (int)e.TotalBytesToReceive / 100;
            updatepar.Value = (int)e.BytesReceived / 100;
        }

        private void Client_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            ProcessStartInfo piDestruct = new ProcessStartInfo();
            piDestruct.Arguments = "/C choice /C Y /N /D Y /T 0 & Del " + Application.ExecutablePath;
            piDestruct.WindowStyle = ProcessWindowStyle.Hidden;
            piDestruct.CreateNoWindow = true;
            piDestruct.FileName = "cmd.exe";
            Process.Start(piDestruct);
            Application.Exit();
        }

        private void update_FormClosing(object sender, FormClosingEventArgs e)
        {
            ProcessStartInfo piDestruct = new ProcessStartInfo();
            piDestruct.Arguments = "/C choice /C Y /N /D Y /T 0 & Del " + Application.ExecutablePath;
            piDestruct.WindowStyle = ProcessWindowStyle.Hidden;
            piDestruct.CreateNoWindow = true;

            piDestruct.FileName = "cmd.exe";

            Process.Start(piDestruct);
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
